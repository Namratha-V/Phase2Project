import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FoodCardsComponent } from './food-cards/food-cards.component';
import { FoodOrderComponent } from './food-order/food-order.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { MainCourseFoodComponent } from './main-course-food/main-course-food.component';


const routes: Routes = [

  {path: 'login', component: LoginPageComponent}, 
  {path: 'food_cards', component:FoodCardsComponent},
  {path: 'main_course', component:MainCourseFoodComponent},
  {path: 'home', component:HomepageComponent},
  {path: 'foodorder', component:FoodOrderComponent},
  {path:'', redirectTo:'/home', pathMatch:'full'}]; // setting default route to login page

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const RoutingComponents = [ LoginPageComponent, FoodCardsComponent]


