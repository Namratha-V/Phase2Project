import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { FormsModule } from '@angular/forms'; // must include in order to use form components like email, passwords ,number etc
import { ReactiveFormsModule } from '@angular/forms';
import { FoodCardsComponent } from './food-cards/food-cards.component';
import { MainCourseFoodComponent } from './main-course-food/main-course-food.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FoodOrderComponent } from './food-order/food-order.component';
import { HomepageComponent } from './homepage/homepage.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    FoodCardsComponent,
    MainCourseFoodComponent,
    FoodOrderComponent,
    HomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule, // for api calls 
    FormsModule // must include in order to use form components like email, passwords ,number etc
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
