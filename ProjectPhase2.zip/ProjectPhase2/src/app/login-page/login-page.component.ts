import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  email?:string ;
  password?:string;
  cred?:string;
  

  loginUser()
    {
      if(this.email== "admin@gmail.com"  && this.password =="admin")
      {
        console.log("Welcome");
        this.router?.navigateByUrl('/food_cards') // navigate to url after success
        this.cred = "success";
      }

      else
      {
      this.cred = "fail";
      }
    }

  constructor(private router?: Router) { }

  ngOnInit(): void {
  }

}
