export class food_list {
    fname : string = '';
    price : number = 0;
    img_url :string = '';
    quan : number = 0;
}