import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule} from '@angular/forms'; // to handle the form elements from HTML components
import {food_list} from '../food_list.model'
import {ApiService} from '../shared/api.service'
@Component({
  selector: 'app-main-course-food',
  templateUrl: './main-course-food.component.html',
  styleUrls: ['./main-course-food.component.css']
})
export class MainCourseFoodComponent implements OnInit {
  formvalue !: FormGroup; 
  foodOBJ :food_list = new food_list(); // foodobj will receive data from front end and it will send it to  APIs
  foodData: any;
 

  constructor(private formbuilder: FormBuilder,  private api : ApiService) { } 

  ngOnInit(): void {
    this.formvalue = this.formbuilder.group({
      fname :[''],
      price : [''],
      img_url : [''],
      quan : ['']

    })
    this.getFoodData();
 }

  postFoodDetails(){
    this.foodOBJ.fname = this.formvalue.value.fname;
    this.foodOBJ.price = this.formvalue.value.price;
    this.foodOBJ.img_url = this.formvalue.value.img_url;
    this.foodOBJ.quan = this.formvalue.value.quan;
    this.api.postFood(this.foodOBJ).subscribe(res=>
      {console.log(res);
      alert("Food added successfully")
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formvalue.reset(); 
      this.getFoodData();
    
    },
      err=>{alert("Something went wrong ");
    
    })
  } // postFoodDetails --> ends

  getFoodData(){
    this.api.getFood().subscribe(res=> { this.foodData= res})
  }

  deleteFoodData(row : any){
    this.api.deleteFood(row.id).subscribe(res=>{
      alert("Food :  "+row.fname+ " \n deleted from the records");
      this.getFoodData();
    })
  }

}
